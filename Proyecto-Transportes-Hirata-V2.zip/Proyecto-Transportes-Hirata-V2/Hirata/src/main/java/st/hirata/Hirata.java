/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package st.hirata;

import Conexion.Conexion;
import java.sql.Connection;

/**
 *
 * @author marti
 */
public class Hirata {

    public static void main(String[] args) {
        System.out.println("Hola Mundo - Transportes Hirata");
        
        try (Connection conn = Conexion.getConexion()) {
            if (conn != null) {
                System.out.println(" Conexión a la base de datos exitosa.");
            } else {
                System.out.println("No se pudo conectar a la base de datos.");
            }
        } catch (Exception e) {
            System.out.println(" Error: " + e.getMessage());
        }
    }
}