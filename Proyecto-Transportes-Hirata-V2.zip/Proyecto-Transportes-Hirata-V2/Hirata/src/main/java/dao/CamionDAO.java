/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modulo.Camion;
import Conexion.Conexion; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Pablo
 */
public class CamionDAO {
    
        public boolean agregarCamion(Camion c) {
        String sql = "INSERT INTO camion (patente, marca, modelo, anio, kilometraje_actual) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, c.getPatente());
            pstmt.setString(2, c.getMarca());
            pstmt.setString(3, c.getModelo());
            pstmt.setInt(4, c.getAnio());
            pstmt.setInt(5, c.getKilometraje());
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al agregar camión: " + e.getMessage());
            return false;
        }
    }

    public boolean registrarKilometraje(Camion c) {
        String sql = "UPDATE camion SET kilometraje_actual = ? WHERE patente = ?";
        try (Connection conn = Conexion.getConexion();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, c.getKilometraje());
            pstmt.setString(2, c.getPatente());
            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("INFO: Kilometraje [" + c.getKilometraje() + " km] guardado.");
                revisarAlertaMantenimiento(c);
                return true;
            } else {
                System.out.println("ADVERTENCIA: Patente " + c.getPatente() + " no encontrada.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar en BD: " + e.getMessage());
            return false;
        }
    }

    private void revisarAlertaMantenimiento(Camion c) {
        if (c.getKilometraje() >= 5000) {
            System.out.println("¡ALERTA DE MANTENIMIENTO! Camión: " + c.getPatente());
            System.out.println("Ha alcanzado o superado los 5000 km.");
        }
    }
    
}
