package dataSimulacion;

import net.datafaker.Faker;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import modulo.Camion;
import modulo.Conductor;
import dao.CamionDAO;
import dao.ConductorDAO;

/**
 * Genera datos falsos (fake data) para poblar la base de datos con
 * conductores y camiones de prueba realistas para el contexto chileno.
 */
public class GeneradorConductores {

    // Faker configurado en español para que los nombres suenen locales
    private static final Faker faker = new Faker(new Locale("es"));

    // Random para seleccionar elementos al azar de nuestras listas propias
    private static final Random random = new Random();

    // Marcas de camiones más usadas en Chile
    private static final String[] MARCAS_REALISTAS = {
        "Mercedes-Benz", "Volvo", "Scania", "Volkswagen", "Renault", "Nissan"
    };

    // -------------------------------------------------------------------------
    // CONDUCTORES
    // -------------------------------------------------------------------------

    /**
     * Inserta conductores con nombres aleatorios en español.
     *
     * @param cantidad número de conductores a insertar
     */
    public static void insertarConductoresFalsos(int cantidad) {
        ConductorDAO dao = new ConductorDAO();
        System.out.println("Insertando " + cantidad + " conductores a la base de datos...");

        for (int i = 0; i < cantidad; i++) {
            String nombreCompleto = faker.name().fullName();
            Conductor c = new Conductor(nombreCompleto);

            if (dao.agregarConductor(c)) {
                System.out.println("  [OK] Conductor insertado: " + nombreCompleto);
            } else {
                System.out.println("  [ERROR] No se pudo insertar: " + nombreCompleto);
            }
        }
        System.out.println("Conductores insertados correctamente.\n");
    }

    // -------------------------------------------------------------------------
    // CAMIONES Y RUTAS
    // -------------------------------------------------------------------------

    /**
     * Inserta camiones con datos aleatorios y realistas.
     *
     * @param cantidad número de camiones a insertar
     * @return Lista de los camiones que fueron insertados exitosamente
     */
    public static List<Camion> insertarCamionesFalsos(int cantidad) {
        CamionDAO dao = new CamionDAO();
        List<Camion> camionesRegistrados = new ArrayList<>();
        
        System.out.println("Insertando " + cantidad + " camiones realistas...");

        for (int i = 0; i < cantidad; i++) {

            // Patente chilena formato nuevo: 4 consonantes (sin M, N, Ñ, Q) + 2 dígitos
            // Ej: BXKL45, ZTMR09
            String patente = faker.regexify("[B-DF-HJ-NP-TV-Z]{4}[0-9]{2}");

            // Marca aleatoria de la lista chilena
            String marca = MARCAS_REALISTAS[random.nextInt(MARCAS_REALISTAS.length)];

            // Modelo genérico combinado con la marca
            String modelo = "Serie " + faker.number().numberBetween(100, 900);

            // Año entre 2009 y 2026
            int anio = faker.number().numberBetween(2009, 2026);

            // Kilometraje inicial aleatorio
            int km = faker.number().numberBetween(500, 23454);

            Camion c = new Camion(patente, marca, modelo, anio, km);

            if (dao.agregarCamion(c)) {
                camionesRegistrados.add(c);
                System.out.println("  [OK] Insertado: [" + patente + "] " + marca + " " + modelo
                        + " | Año: " + anio + " | Km: " + km);
            } else {
                System.out.println("  [SKIP] Patente duplicada o error: " + patente);
            }
        }

        System.out.println("Camiones insertados correctamente.\n");
        return camionesRegistrados;
    }

   /**
     * Imprime un listado a modo de historial de ruta de los camiones generados.
     * @param camiones Lista de camiones a mostrar en el historial
     */
    public static void imprimirHistorialRuta(List<Camion> camiones) {
        System.out.println("==========================================");
        System.out.println("           HISTORIAL DE RUTA              ");
        System.out.println("==========================================");
        
        if (camiones.isEmpty()) {
            System.out.println("No hay camiones registrados en esta ruta.");
            return;
        }

        for (Camion c : camiones) {
            // Se actualizó a getKilometraje() para coincidir con tu clase Camion
            System.out.printf("Patente: %-8s | Kilometraje actual: %,d km%n", 
                              c.getPatente(), c.getKilometraje());
        }
        System.out.println("==========================================\n");
    }
    
    // -------------------------------------------------------------------------
    // MÉTODO MAIN DE PRUEBA (Opcional, para que veas cómo llamarlo)
    // -------------------------------------------------------------------------
    public static void main(String[] args) {
        // Generar conductores (opcional para el test)
        // insertarConductoresFalsos(5);
        
        // 1. Crear la data fake y guardar la lista resultante
        List<Camion> camionesGenerados = insertarCamionesFalsos(10);
        
        // 2. Pasar la lista al historial de ruta para mostrarla
        imprimirHistorialRuta(camionesGenerados);
    }
}