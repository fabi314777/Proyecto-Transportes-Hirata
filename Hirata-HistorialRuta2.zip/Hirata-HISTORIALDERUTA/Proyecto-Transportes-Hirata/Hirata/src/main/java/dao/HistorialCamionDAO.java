package dao;

import Conexion.Conexion;
import modulo.HistorialCamion;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class HistorialCamionDAO {

    /**
     * Registra una ruta. También actualiza el kilometraje_actual del camión.
     */
    public boolean registrarRuta(HistorialCamion h) {
        String sqlHistorial = "INSERT INTO historialCamion (patente_camion, fecha_ruta, km_inicio, km_fin) "
                            + "VALUES (?, ?, ?, ?)";
        String sqlActualizar = "UPDATE camion SET kilometraje_actual = ? WHERE patente = ?";

        try (Connection conn = Conexion.getConexion()) {
            conn.setAutoCommit(false); // transacción

            try (PreparedStatement ps1 = conn.prepareStatement(sqlHistorial);
                 PreparedStatement ps2 = conn.prepareStatement(sqlActualizar)) {

                ps1.setString(1, h.getPatenteCamion());
                ps1.setDate(2, Date.valueOf(h.getFechaRuta()));
                ps1.setInt(3, h.getKmInicio());
                ps1.setInt(4, h.getKmFin());
                ps1.executeUpdate();

                // actualizar odómetro del camión con km_fin
                ps2.setInt(1, h.getKmFin());
                ps2.setString(2, h.getPatenteCamion());
                ps2.executeUpdate();

                conn.commit();
                return true;

            } catch (SQLException e) {
                conn.rollback();
                System.out.println("Error al registrar ruta: " + e.getMessage());
                return false;
            }

        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            return false;
        }
    }

    /**
     * Lista todo el historial de una patente específica.
     */
    public List<HistorialCamion> listarPorPatente(String patente) {
        List<HistorialCamion> lista = new ArrayList<>();
        String sql = "SELECT * FROM historialCamion WHERE patente_camion = ? ORDER BY fecha_ruta DESC";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, patente);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new HistorialCamion(
                    rs.getInt("id_historial"),
                    rs.getString("patente_camion"),
                    rs.getDate("fecha_ruta").toLocalDate(),
                    rs.getInt("km_inicio"),
                    rs.getInt("km_fin"),
                    rs.getInt("km_recorridos")
                ));
            }

        } catch (SQLException e) {
            System.out.println("Error al listar historial: " + e.getMessage());
        }
        return lista;
    }

    /**
     * Lista el historial completo de todos los camiones.
     */
    public List<HistorialCamion> listarTodo() {
        List<HistorialCamion> lista = new ArrayList<>();
        String sql = "SELECT * FROM historialCamion ORDER BY fecha_ruta DESC";

        try (Connection conn = Conexion.getConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new HistorialCamion(
                    rs.getInt("id_historial"),
                    rs.getString("patente_camion"),
                    rs.getDate("fecha_ruta").toLocalDate(),
                    rs.getInt("km_inicio"),
                    rs.getInt("km_fin"),
                    rs.getInt("km_recorridos")
                ));
            }

        } catch (SQLException e) {
            System.out.println("Error al listar todo el historial: " + e.getMessage());
        }
        return lista;
    }
}