package modulo;

import java.time.LocalDate;

public class HistorialCamion {

    private int idHistorial;
    private String patenteCamion;
    private LocalDate fechaRuta;
    private int kmInicio;
    private int kmFin;
    private int kmRecorridos; // calculado: kmFin - kmInicio

    public HistorialCamion(String patenteCamion, LocalDate fechaRuta, int kmInicio, int kmFin) {
        this.patenteCamion = patenteCamion;
        this.fechaRuta = fechaRuta;
        this.kmInicio = kmInicio;
        this.kmFin = kmFin;
        this.kmRecorridos = kmFin - kmInicio;
    }

    // Constructor completo (para leer desde BD)
    public HistorialCamion(int idHistorial, String patenteCamion, LocalDate fechaRuta,
            int kmInicio, int kmFin, int kmRecorridos) {
        this.idHistorial = idHistorial;
        this.patenteCamion = patenteCamion;
        this.fechaRuta = fechaRuta;
        this.kmInicio = kmInicio;
        this.kmFin = kmFin;
        this.kmRecorridos = kmRecorridos;
    }

    public int getIdHistorial() {
        return idHistorial;
    }

    public String getPatenteCamion() {
        return patenteCamion;
    }

    public LocalDate getFechaRuta() {
        return fechaRuta;
    }

    public int getKmInicio() {
        return kmInicio;
    }

    public int getKmFin() {
        return kmFin;
    }

    public int getKmRecorridos() {
        return kmRecorridos;
    }
}
