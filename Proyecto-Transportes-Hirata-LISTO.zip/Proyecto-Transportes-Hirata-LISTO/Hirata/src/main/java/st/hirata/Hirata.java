package st.hirata;

import vista.VistaFlota;

/**
 *Author fchmm
 */

public class Hirata { 

    public static void main(String[] args) {
        // CrossPlatformLookAndFeel = Look&Feel propio de Java
        // Esto evita que Windows sobreescriba los colores definidos en el codigo
        try {
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getCrossPlatformLookAndFeelClassName()
            );
        } catch (Exception e) {
            // Si falla usa el L&F por defecto
        }

        javax.swing.SwingUtilities.invokeLater(() -> {
            VistaFlota ventana = new VistaFlota();
            ventana.setVisible(true);
        });
    }
}
