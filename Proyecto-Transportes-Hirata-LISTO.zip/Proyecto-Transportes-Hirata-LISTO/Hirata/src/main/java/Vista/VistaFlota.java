package vista;

import dao.CamionDAO;
import dao.ConductorDAO;
import modulo.Camion;
import modulo.Conductor;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 *Author fchmm
 */
public class VistaFlota extends JFrame {
    static final Color AZUL       = new Color(41, 128, 185);
    static final Color VERDE      = new Color(39, 174, 96);
    static final Color ROJO       = new Color(192, 57, 43);
    static final Color AMARILLO   = new Color(230, 126, 34);
    static final Color FONDO      = new Color(245, 247, 250);
    static final Color BLANCO     = Color.WHITE;
    static final Color GRIS_BORDE = new Color(210, 215, 220);
    static final Color GRIS_TEXTO = new Color(100, 110, 120);
    static final Color HEADER_BG  = new Color(44, 62, 80);

 
    private final CamionDAO    camionDAO    = new CamionDAO();
    private final ConductorDAO conductorDAO = new ConductorDAO();


    private DefaultTableModel modeloTablaKm;
    private DefaultTableModel modeloTablaInfo;
    private DefaultTableModel modeloTablaConductores;

    public VistaFlota() {
        setTitle("Transportes Hirata — Gestión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 620);
        setLocationRelativeTo(null);
        setBackground(FONDO);
        setLayout(new BorderLayout());

        add(crearHeader(), BorderLayout.NORTH);
        add(crearTabs(),   BorderLayout.CENTER);
        add(crearFooter(), BorderLayout.SOUTH);
    }

   
    private JPanel crearHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_BG);
        header.setPreferredSize(new Dimension(0, 60));
        header.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        JLabel icono = new JLabel("--");
        icono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));

        JPanel textos = new JPanel(new GridLayout(2, 1));
        textos.setOpaque(false);
        JLabel titulo = new JLabel("TRANSPORTES HIRATA");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        titulo.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Sistema de Gestión");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(180, 190, 200));
        textos.add(titulo);
        textos.add(sub);

        left.add(icono);
        left.add(textos);
        header.add(left, BorderLayout.WEST);

        JLabel usuario = new JLabel("  Administrador");
        usuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        usuario.setForeground(new Color(180, 190, 200));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(usuario);
        header.add(right, BorderLayout.EAST);

        return header;
    }

   
    private JTabbedPane crearTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        tabs.addTab("    Registrar Kilometraje  ",  crearPanelKm());
        tabs.addTab("    Camiones y Conductores  ", crearPanelInfo());
        tabs.addTab("    Conductores  ",            crearPanelConductores());
        return tabs;
    }

  
    private JPanel crearPanelKm() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        panel.add(crearTitulo(
            " Registrar Kilometraje",
            "Ingrese el kilometraje al finalizar cada recorrido"
        ), BorderLayout.NORTH);

     
        String[] cols = {"Patente", "Marca / Modelo", "Año", "Conductor", "Km Actuales"};
        modeloTablaKm = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabla = crearTabla(modeloTablaKm);
     
        tabla.getColumnModel().getColumn(0).setPreferredWidth(90);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(180);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(160);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(110);
        

        cargarTablaKm();

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(GRIS_BORDE));
        panel.add(scroll, BorderLayout.CENTER);


        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setBackground(FONDO);

       
       

        JButton btnRegistrar = crearBoton(" Registrar Kilometraje", AZUL);
        btnRegistrar.addActionListener(e -> dialogoRegistrarKm(tabla));

       
        botones.add(btnRegistrar);
        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    private void cargarTablaKm() {
    modeloTablaKm.setRowCount(0);

    try {
        List<Camion> lista = camionDAO.listarCamiones();

       

        for (Camion c : lista) {
            modeloTablaKm.addRow(new Object[]{
                c.getPatente(),
                c.getMarca() + " " + c.getModelo(),
                c.getAnio(),
                "Sin conductor",
                c.getKilometraje() + " km"
            });
        }

    } catch (Exception e) {
  // sin conexion, tabla vacia
    }
}

    
    

   
    private void dialogoRegistrarKm(JTable tabla) {
        JDialog dlg = new JDialog(this, "Registrar Kilometraje", true);
        dlg.setSize(420, 240);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());
        dlg.getContentPane().setBackground(BLANCO);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 10, 24));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 4, 7, 4);
        g.fill   = GridBagConstraints.HORIZONTAL;

       
        g.gridx = 0; g.gridy = 0; g.weightx = 0.35;
        form.add(crearLabel("Patente del camión:"), g);
        JTextField tfPatente = crearCampo("Ej: BJKL-45");
       
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada >= 0) {
            tfPatente.setText((String) modeloTablaKm.getValueAt(filaSeleccionada, 0));
        }
        g.gridx = 1; g.weightx = 0.65;
        form.add(tfPatente, g);

       
        g.gridx = 0; g.gridy = 1; g.weightx = 0.35;
        form.add(crearLabel("Nuevo kilometraje:"), g);
        JTextField tfKm = crearCampo("Ej: 2500");
        g.gridx = 1; g.weightx = 0.65;
        form.add(tfKm, g);

        dlg.add(form, BorderLayout.CENTER);

        
        JPanel bp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        bp.setBackground(BLANCO);
        bp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, GRIS_BORDE));

        JButton btnCancelar = crearBotonSecundario("Cancelar");
        btnCancelar.addActionListener(e -> dlg.dispose());

        JButton btnGuardar = crearBoton("Guardar", VERDE);
        btnGuardar.addActionListener(e -> {
            String patente = tfPatente.getText().trim();
            String kmStr   = tfKm.getText().trim();

           
            if (patente.isEmpty()) {
                error(dlg, "Ingrese la patente del camión.");
                return;
            }
            if (kmStr.isEmpty() || !kmStr.matches("\\d+")) {
                error(dlg, "Ingrese un kilometraje válido (solo números).");
                return;
            }
            int km = Integer.parseInt(kmStr);
            if (km <= 0) {
                error(dlg, "El kilometraje debe ser mayor a cero.");
                return;
            }

           
            Camion c = new Camion(patente, "", "", 0, km);
            boolean ok = camionDAO.registrarKilometraje(c);

            if (ok) {
                dlg.dispose();
                cargarTablaKm();
                cargarTablaInfo();
                exito(this, "Kilometraje registrado correctamente para la patente " + patente + ".");
            } else {
                error(dlg, "No se pudo registrar. Verifique la patente o la conexión a la base de datos.");
            }
        });

        bp.add(btnCancelar);
        bp.add(btnGuardar);
        dlg.add(bp, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    private JPanel crearPanelInfo() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        panel.add(crearTitulo(
            " Camiones y Conductores",
            "Registre y administre la información de cada camión y su conductor asignado "
        ), BorderLayout.NORTH);

        String[] cols = {"Patente", "Marca", "Modelo", "Año", "Km Actuales", "Conductor Asignado"};
        modeloTablaInfo = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabla = crearTabla(modeloTablaInfo);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(90);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(110);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(110);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(180);

        cargarTablaInfo();

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(GRIS_BORDE));
        panel.add(scroll, BorderLayout.CENTER);

        
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setBackground(FONDO);

        
        

        JButton btnNuevo = crearBoton(" Agregar Camión", AZUL);
        btnNuevo.addActionListener(e -> dialogoCamion(null, tabla));

       
        botones.add(btnNuevo);
    JButton btnAsignar = crearBoton("Asignar Conductor", new Color(142, 68, 173));
    btnAsignar.addActionListener(e -> {
        int fila = tabla.getSelectedRow();
        if (fila < 0) { error(this, "Seleccione un camion de la tabla primero."); return; }
        String patente = (String) modeloTablaInfo.getValueAt(fila, 0);
        dialogoAsignarConductor(patente);
    });
    botones.add(btnAsignar);
        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    private void cargarTablaInfo() {
    modeloTablaInfo.setRowCount(0);
    try {
        List<String[]> lista = camionDAO.listarCamionesConConductor();
        for (String[] fila : lista) {
            modeloTablaInfo.addRow(fila);
        }
    } catch (Exception e) {
        // sin conexion, tabla vacia
    }

}
    
    private void dialogoCamion(Camion camionEditar, JTable tabla) {
        boolean esNuevo = (camionEditar == null);
        JDialog dlg = new JDialog(this, esNuevo ? "Nuevo Camión" : "Editar Camión", true);
        dlg.setSize(440, 360);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());
        dlg.getContentPane().setBackground(BLANCO);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 10, 24));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 4, 7, 4);
        g.fill   = GridBagConstraints.HORIZONTAL;

        JTextField tfPatente  = crearCampo("Ej: BJKL-45");
        JTextField tfMarca    = crearCampo("Ej: Volvo");
        JTextField tfModelo   = crearCampo("Ej: FH16");
        JTextField tfAnio     = crearCampo("Ej: 2022");
        JTextField tfKm       = crearCampo("Ej: 0");

       
        

        if (!esNuevo) {
            tfPatente.setText(camionEditar.getPatente());
            tfPatente.setEditable(false);
            tfPatente.setBackground(new Color(236, 240, 241));
            tfMarca.setText(camionEditar.getMarca());
            tfModelo.setText(camionEditar.getModelo());
            tfAnio.setText(String.valueOf(camionEditar.getAnio()));
            tfKm.setText(String.valueOf(camionEditar.getKilometraje()));
        }

        String[]     labels = {"Patente:",  "Marca:",  "Modelo:",  "Año:",  "Km Iniciales:"};
        Component[]  comps  = {tfPatente,   tfMarca,   tfModelo,   tfAnio,  tfKm            };

        for (int i = 0; i < labels.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0.35;
            form.add(crearLabel(labels[i]), g);
            g.gridx = 1; g.weightx = 0.65;
            form.add(comps[i], g);
        }

        dlg.add(form, BorderLayout.CENTER);

        JPanel bp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        bp.setBackground(BLANCO);
        bp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, GRIS_BORDE));

        JButton btnCancelar = crearBotonSecundario("Cancelar");
        btnCancelar.addActionListener(e -> dlg.dispose());

        JButton btnGuardar = crearBoton("Guardar", VERDE);
        btnGuardar.addActionListener(e -> {
            // Validaciones 
            if (tfPatente.getText().trim().isEmpty() || tfMarca.getText().trim().isEmpty()
                    || tfModelo.getText().trim().isEmpty()) {
                error(dlg, "Patente, marca y modelo son obligatorios.");
                return;
            }
            if (!tfAnio.getText().trim().matches("\\d{4}")) {
                error(dlg, "Ingrese un año válido (4 dígitos).");
                return;
            }
            if (!tfKm.getText().trim().matches("\\d+")) {
                error(dlg, "Ingrese un kilometraje válido (solo números).");
                return;
            }

            Camion nuevo = new Camion(
                tfPatente.getText().trim().toUpperCase(),
                tfMarca.getText().trim(),
                tfModelo.getText().trim(),
                Integer.parseInt(tfAnio.getText().trim()),
                Integer.parseInt(tfKm.getText().trim())
            );

            boolean ok = camionDAO.agregarCamion(nuevo);
            if (ok) {
                dlg.dispose();
                cargarTablaInfo();
                cargarTablaKm();
                exito(this, "Camión " + nuevo.getPatente() + " registrado correctamente.");
            } else {
                error(dlg, "No se pudo guardar. Verifique que la patente no exista o revise la conexión a la base de datos.");
            }
        });

        bp.add(btnCancelar);
        bp.add(btnGuardar);
        dlg.add(bp, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    private JPanel crearPanelConductores() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        panel.add(crearTitulo(
            " Conductores",
            "Registre los conductores para asignarlos a los camiones "
        ), BorderLayout.NORTH);

        String[] cols = {"ID", "Nombre"};
        modeloTablaConductores = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabla = crearTabla(modeloTablaConductores);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(300);

        cargarTablaConductores();

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(GRIS_BORDE));
        panel.add(scroll, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setBackground(FONDO);

        
        
        JButton btnNuevo = crearBoton(" Agregar Conductor", AZUL);
        btnNuevo.addActionListener(e -> dialogoNuevoConductor());

       
        botones.add(btnNuevo);
        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    private void cargarTablaConductores() {
        modeloTablaConductores.setRowCount(0);
        try {
            List<Conductor> lista = conductorDAO.listarConductores();
            for (Conductor c : lista) {
                modeloTablaConductores.addRow(new Object[]{c.getIdConductor(), c.getNombre()});
            }
            
        } catch (Exception ex) {
            // sin conexion, tabla vacia
        }
    }

    private void dialogoNuevoConductor() {
        JDialog dlg = new JDialog(this, "Nuevo Conductor", true);
        dlg.setSize(380, 180);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());
        dlg.getContentPane().setBackground(BLANCO);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 10, 24));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(7, 4, 7, 4);
        g.fill   = GridBagConstraints.HORIZONTAL;

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35;
        form.add(crearLabel("Nombre completo:"), g);
        JTextField tfNombre = crearCampo("Ej: Juan Pérez");
        g.gridx = 1; g.weightx = 0.65;
        form.add(tfNombre, g);

        dlg.add(form, BorderLayout.CENTER);

        JPanel bp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        bp.setBackground(BLANCO);
        bp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, GRIS_BORDE));

        JButton btnCancelar = crearBotonSecundario("Cancelar");
        btnCancelar.addActionListener(e -> dlg.dispose());

        JButton btnGuardar = crearBoton("Guardar", VERDE);
        btnGuardar.addActionListener(e -> {
            String nombre = tfNombre.getText().trim();
            if (nombre.isEmpty()) {
                error(dlg, "Ingrese el nombre del conductor.");
                return;
            }
            Conductor c = new Conductor(nombre);
            boolean ok = conductorDAO.agregarConductor(c);
            if (ok) {
                dlg.dispose();
                cargarTablaConductores();
                exito(this, "Conductor registrado correctamente.");
            } else {
                error(dlg, "No se pudo guardar. Revise la conexión a la base de datos.");
            }
        });

        bp.add(btnCancelar);
        bp.add(btnGuardar);
        dlg.add(bp, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void dialogoAsignarConductor(String patente) {
    JDialog dlg = new JDialog(this, "Asignar Conductor", true);
    dlg.setSize(380, 180);
    dlg.setLocationRelativeTo(this);
    dlg.setLayout(new BorderLayout());
    dlg.getContentPane().setBackground(BLANCO);

    JPanel form = new JPanel(new GridBagLayout());
    form.setBackground(BLANCO);
    form.setBorder(BorderFactory.createEmptyBorder(20, 24, 10, 24));
    GridBagConstraints g = new GridBagConstraints();
    g.insets = new Insets(7, 4, 7, 4);
    g.fill = GridBagConstraints.HORIZONTAL;

    g.gridx = 0; g.gridy = 0; g.weightx = 0.35;
    form.add(crearLabel("Camion:"), g);
    JLabel lblPatente = new JLabel(patente);
    lblPatente.setFont(new Font("Segoe UI", Font.BOLD, 13));
    lblPatente.setForeground(AZUL);
    g.gridx = 1; g.weightx = 0.65;
    form.add(lblPatente, g);

    g.gridx = 0; g.gridy = 1; g.weightx = 0.35;
    form.add(crearLabel("Conductor:"), g);
    JComboBox<Conductor> cbConductor = new JComboBox<>();
    cbConductor.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    cbConductor.setBackground(Color.WHITE);
    cbConductor.setForeground(Color.BLACK);
    List<Conductor> lista = conductorDAO.listarConductores();
    for (Conductor c : lista) cbConductor.addItem(c);
    if (cbConductor.getItemCount() == 0) {
        error(this, "No hay conductores registrados. Agregue uno primero.");
        return;
    }
    g.gridx = 1; g.weightx = 0.65;
    form.add(cbConductor, g);
    dlg.add(form, BorderLayout.CENTER);

    JPanel bp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
    bp.setBackground(BLANCO);
    bp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, GRIS_BORDE));
    JButton btnCancelar = crearBotonSecundario("Cancelar");
    btnCancelar.addActionListener(e -> dlg.dispose());
    JButton btnGuardar = crearBoton("Asignar", VERDE);
    btnGuardar.addActionListener(e -> {
        Conductor seleccionado = (Conductor) cbConductor.getSelectedItem();
        if (seleccionado == null) return;
        boolean ok = camionDAO.asignarConductor(patente, seleccionado.getIdConductor());
        if (ok) {
            dlg.dispose();
            cargarTablaInfo();
            exito(this, "Conductor asignado correctamente al camion " + patente + ".");
        } else {
            error(dlg, "No se pudo asignar. Revise la conexion.");
        }
    });
    bp.add(btnCancelar);
    bp.add(btnGuardar);
    dlg.add(bp, BorderLayout.SOUTH);
    dlg.setVisible(true);
}
    
    
    private JPanel crearFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(236, 240, 241));
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, GRIS_BORDE));
        footer.setPreferredSize(new Dimension(0, 28));
        JLabel lbl = new JLabel("");
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lbl.setForeground(new Color(60, 70, 80));
        footer.add(lbl, BorderLayout.WEST);
        return footer;
    }

   
    private JPanel crearTitulo(String titulo, String descripcion) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 2));
        p.setBackground(FONDO);
        p.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        JLabel t = new JLabel(titulo);
        t.setFont(new Font("Segoe UI", Font.BOLD, 17));
        t.setForeground(HEADER_BG);
        JLabel d = new JLabel(descripcion);
        d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        d.setForeground(GRIS_TEXTO);
        p.add(t); p.add(d);
        return p;
    }

    private JTable crearTabla(DefaultTableModel modelo) {
    JTable tabla = new JTable(modelo);
    tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    tabla.setForeground(Color.BLACK);
    tabla.setBackground(Color.WHITE);
    tabla.setRowHeight(32);
    tabla.setShowGrid(false);
    tabla.setIntercellSpacing(new Dimension(0, 0));
    tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    tabla.getTableHeader().setBackground(HEADER_BG);
    tabla.getTableHeader().setForeground(Color.WHITE);
    tabla.getTableHeader().setPreferredSize(new Dimension(0, 36));
    tabla.setSelectionBackground(new Color(174, 214, 241));
    tabla.setSelectionForeground(Color.BLACK);
    tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v,
                boolean sel, boolean foc, int row, int col) {
            super.getTableCellRendererComponent(t, v, sel, foc, row, col);
            setForeground(Color.BLACK);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            if (sel) {
                setBackground(new Color(174, 214, 241));
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 244, 248));
            }
            return this;
        }
    });
    return tabla;
}

    private JButton crearBoton(String texto, Color color) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(color.brighter()); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(color); }
        });
        return btn;
    }

    private JButton crearBotonSecundario(String texto) {
        JButton btn = crearBoton(texto, new Color(189, 195, 199));
        btn.setForeground(new Color(50, 50, 50));
        return btn;
    }

    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(new Color(60, 70, 80));
        return lbl;
    }

    private JTextField crearCampo(String tooltip) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(Color.WHITE);
tf.setForeground(new Color(30, 30, 30));
tf.setCaretColor(new Color(30, 30, 30));
        tf.setBackground(Color.WHITE);
        tf.setForeground(new Color(30, 30, 30));
        tf.setCaretColor(new Color(30, 30, 30));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(GRIS_BORDE),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        tf.setToolTipText(tooltip);
        return tf;
    }

    private void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, "  " + msg, "Error de validación", JOptionPane.ERROR_MESSAGE);
    }

    private void exito(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, "  " + msg, "Operación exitosa", JOptionPane.INFORMATION_MESSAGE);
    }

    
    static class EstadoRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable t, Object v,
            boolean sel, boolean foc, int row, int col) {
        super.getTableCellRendererComponent(t, v, sel, foc, row, col);
        setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        String val = v != null ? v.toString() : "";
        if (sel) {
            setBackground(new Color(174, 214, 241));
            setForeground(Color.BLACK);
        } else {
            setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 244, 248));
            if      (val.contains("Mantenimiento")) { setForeground(new Color(180, 0, 0));   setFont(getFont().deriveFont(Font.BOLD)); }
            else if (val.contains("Próx"))          { setForeground(new Color(180, 90, 0));  setFont(getFont().deriveFont(Font.BOLD)); }
            else                                    { setForeground(new Color(0, 130, 70));  setFont(getFont().deriveFont(Font.PLAIN)); }
        }
        return this;
    }
}
}