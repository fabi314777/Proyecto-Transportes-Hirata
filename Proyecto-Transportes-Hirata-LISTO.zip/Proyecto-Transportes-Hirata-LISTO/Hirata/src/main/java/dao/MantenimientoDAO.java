/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Conexion.Conexion;
import modulo.Mantenimiento;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kevin
 */
public class MantenimientoDAO {

    public boolean registrarMantenimiento(Mantenimiento m) {
        String sql = "INSERT INTO mantenimiento (patente_camion, fecha, descripcion) VALUES (?, ?, ?)";
        try (Connection conn = Conexion.getConexion();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, m.getPatenteCamion());
            pstmt.setDate(2, Date.valueOf(m.getFecha()));
            pstmt.setString(3, m.getDescripcion());
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar mantenimiento: " + e.getMessage());
            return false;
        }
    }

    public List<Mantenimiento> listarMantenimientos() {
        List<Mantenimiento> lista = new ArrayList<>();
        String sql = "SELECT id_mantenimiento, patente_camion, fecha, descripcion FROM mantenimiento";
        try (Connection conn = Conexion.getConexion();
                PreparedStatement pstmt = conn.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                lista.add(new Mantenimiento(
                        rs.getInt("id_mantenimiento"),
                        rs.getString("patente_camion"),
                        rs.getDate("fecha").toLocalDate(),
                        rs.getString("descripcion")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar mantenimientos: " + e.getMessage());
        }
        return lista;
    }
}
