/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Conexion.Conexion;
import modulo.Conductor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author kevin
 */
public class ConductorDAO {

    public boolean agregarConductor(Conductor c) {
        String sql = "INSERT INTO conductor (nombre) VALUES (?)";
        try (Connection conn = Conexion.getConexion();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, c.getNombre());
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al agregar conductor: " + e.getMessage());
            return false;
        }
    }

    public List<Conductor> listarConductores() {
        List<Conductor> lista = new ArrayList<>();
        String sql = "SELECT id_conductor, nombre FROM conductor";
        try (Connection conn = Conexion.getConexion();
                PreparedStatement pstmt = conn.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                lista.add(new Conductor(rs.getInt("id_conductor"), rs.getString("nombre")));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar conductores: " + e.getMessage());
        }
        return lista;
    }
}
