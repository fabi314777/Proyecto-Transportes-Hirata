package st.hirata;
//Importaciones necesarias para que el codigo se ejecute de manera correcta
import vista.VistaFlota;
import dataSimulacion.GeneradorConductores; //import para poder generar la fake data
//necesario para pruebas

/**
 *Author fchmm
 */

public class Hirata { 

    public static void main(String[] args) {
        // CrossPlatformLookAndFeel = Look&Feel propio de Java
        // Esto evita que Windows sobreescriba los colores definidos en el codigo
        //esta seccion permiete mostrar la ventana (las vistas)
        try {
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getCrossPlatformLookAndFeelClassName()
            );
        } catch (Exception e) {
            // Si falla usa el L&F por defecto
        }
        //esta seccion es la que usaremos para poder crear una datafake tanto de conductores y camiones
        GeneradorConductores.insertarConductoresFalsos(10);
        GeneradorConductores.insertarCamionesFalsos(10);

        javax.swing.SwingUtilities.invokeLater(() -> {
            VistaFlota ventana = new VistaFlota();
            ventana.setVisible(true);
        });
    }
}
