/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataSimulacion;
import net.datafaker.Faker;//Libreria externa que es incluida via Maven necesario para crear la datafake
import java.util.Locale;
import modulo.Camion;
import modulo.Conductor; 
import dao.CamionDAO;
import dao.ConductorDAO; 
import java.util.Random;// se utiliza para poder sacar resultados al azar

public class GeneradorConductores {
    // Faker configurado en español ("es") para que los nombres suenen locale
    private static final Faker faker = new Faker(new Locale("es"));
    // Objeto Random para seleccionar elementos aleatorios de nuestras propias listas
    private static final Random random = new Random();

    /**
     * Inserta conductores (nombres de personas) aleatorios
     */
    public static void insertarConductoresFalsos(int cantidad) {
        ConductorDAO dao = new ConductorDAO();
        System.out.println("Insertando " + cantidad + " conductores a la base de datos...");

        for (int i = 0; i < cantidad; i++) {
            // // faker.name().fullName() genera un "Nombre + Apellido" realista
            String nombreCompleto = faker.name().fullName();
            
            // Se crea el objeto modelo 'Conductor' con el nombre generado
            Conductor c = new Conductor(nombreCompleto);
            // Se intenta guardar en la BD. Si el DAO retorna true, confirmamos en consola.
            if (dao.agregarConductor(c)) {
                System.out.println("Conductor insertado: " + nombreCompleto);
            }
        }
    }

    /**
     * Inserta camiones aleatorios
     */
    /*SECCIÓN 2: Listas Personalizadas
    se agrega una lista de marcas de camiones que mas se utilizan en chile para darle mas realismo
    al dataFake*/
    private static final String[] MARCAS_REALISTAS = {
        "Mercedes-Benz", "Volvo", "Scania", "Volkswagen", "Renault", "Nissan"
    };
    //SECCIÓN 3: Inserción de Camiones

    public static void insertarCamionesFalsos(int cantidad) {
        CamionDAO dao = new CamionDAO();
        System.out.println("Insertando " + cantidad + " camiones realistas...");

        for (int i = 0; i < cantidad; i++) {
            // 1. Patente Chilena (4 letras mayúsculas + 2 números)
            // Faker.regexify permite crear formatos exactos
            /* 1. Generación de Patente con REGEXIFY
               Usamos una expresión regular para cumplir el formato chileno:
               [B-Z]{4} -> Genera 4 letras mayúsculas aleatorias (excluyendo la A por norma).
               [0-9]{2} -> Genera 2 números finales. */
            String patente = faker.regexify("[B-Z]{4}[0-9]{2}"); 
            
            // 2. Marca aleatoria de nuestra lista
            String marca = MARCAS_REALISTAS[random.nextInt(MARCAS_REALISTAS.length)];
            
            // 3. Modelo genérico o ficticio que combine con la marca
            String modelo = "Serie " + faker.number().numberBetween(100, 900);
            
            int anio = faker.number().numberBetween(2009, 2026);
            int km = faker.number().numberBetween(500, 23454);

            Camion c = new Camion(patente, marca, modelo, anio, km);

            if (dao.agregarCamion(c)) {
                System.out.println("Insertado: [" + patente + "] " + marca + " " + modelo);
            }
        }
    }
}
